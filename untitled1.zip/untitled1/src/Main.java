import java.util.ArrayList;
import java.util.Scanner;

class Car {
    String brand;
    String model;
    int horsePower;

    Car(String b, String m, int h) {
        brand = b;
        model = m;
        horsePower = h;
    }

    void carInfo() {
        System.out.println("The car is: " + brand + " " + model + " - " + horsePower + " HP.");
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        ArrayList<Car> cars = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String[] carInfo = scanner.nextLine().split(" ");
            String brand = carInfo[0];
            String model = carInfo[1];
            int horsePower = Integer.parseInt(carInfo[2]);
            Car car = new Car(brand, model, horsePower);
            cars.add(car);
        }

        for (int i = 0; i < cars.size(); i++) {
            Car car = cars.get(i);
            car.carInfo();
        }
    }
}
